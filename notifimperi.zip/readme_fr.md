# Installation
Gestion des Notifications TTS via API ImperiHome  
Compatible avec chatBOT et Ask.
    
  
### Ajout du p�riph�rique
Cliquez sur "Configuration" / "Ajouter ou supprimer un p�riph�rique" / "Store eedomus" / "Notifications TTS Imperihome" / "Cr�er"  

  
*Voici les diff�rents champs � renseigner:*

* [Obligatoire] - L'IP fixe du device sur lequel tourne Imperihome (avec API activ�e)
* [Obligatoire] - Le port d'acc�s � l'API Imperihome 

  
### Utilisation
Pr�d�finissez des notifications dans les valeurs du p�riph�rique cr�� par le plugin.  
Respectez bien la forme des valeurs et l'url du script appel�, � l'instar des valeurs par d�faut fournies � la cr�ation.  
*NB1 : Ne supprimez pas la valeur cach�e 9999 - [CHATBOT], d�di�e au plugin du m�me nom.*  
*NB2 : Ne supprimez pas la valeur cach�e 99999 - [ASK], d�di�e au plugin du m�me nom.*  
 
Vous pouvez int�grer la valeur d'un ou plusieurs p�riph�riques existants via son code API entre crochet, exemple : [123456].  

Lancez ensuite vos notifications depuis vos r�gles.  

